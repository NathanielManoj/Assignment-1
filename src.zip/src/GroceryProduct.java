public interface GroceryProduct {

    //Factory method.
     void setPrice(double price);

     double getPrice();

}

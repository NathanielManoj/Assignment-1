

// Abstract factory pattern.
public interface GroceryProductFactory {

    GroceryProduct createProduct();
}
